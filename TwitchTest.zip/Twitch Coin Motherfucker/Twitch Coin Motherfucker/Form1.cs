﻿using Twitch_Coin_Motherfucker.Properties;
using System;
using System.Windows;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Timer = System.Threading.Timer;
using System.Drawing.Imaging;
using System.Diagnostics;

namespace Twitch_Coin_Motherfucker
{
    public partial class Form1 : Form
    {

        private const UInt32 MOUSEEVENTF_LEFTDOWN = 0x0002;
        private const UInt32 MOUSEEVENTF_LEFTUP = 0x0004;

        [DllImport("user32.dll")]
        private static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, uint dwExtraInf);

        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int x, int y);

        public Form1()
        {
            InitializeComponent();
        }

        public bool SearchPixel(string hexcode)
        {
            //Bitmap bitmap = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            Bitmap bitmap = new Bitmap(SystemInformation.VirtualScreen.Width, SystemInformation.VirtualScreen.Height);

            Graphics graphics = Graphics.FromImage(bitmap as Image);

            graphics.CopyFromScreen(0, 0, 0, 0, bitmap.Size);

            Color desiredPixelColor = ColorTranslator.FromHtml(hexcode);

            for (int x = 0; x < SystemInformation.VirtualScreen.Width; x++)
            {
                for (int y = 0; y < SystemInformation.VirtualScreen.Height; y++)
                {
                    Color currentPixelColor = bitmap.GetPixel(x, y);

                    if (desiredPixelColor == currentPixelColor)
                    {
                        //MessageBox.Show("Found Pixel - Now set mouse cursor");
                        DoubleClickAtPosition(x, y);
                        ResumeSearch();
                        return true;
                    }

                }
            }
            string inputHexColorCode = textBox1.Text;
            SearchPixel(inputHexColorCode);
            //MessageBox.Show("Did not find pixel");
            return false;
        }

        public void ResumeSearch()
        {
            string inputHexColorCode = textBox1.Text;
            SearchPixel(inputHexColorCode);
        }

        //public bool AutoSearchPixel(string hexcode)
        //{
            //Bitmap bitmap = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);

            //Bitmap bitmap = new Bitmap(SystemInformation.VirtualScreen.Width, SystemInformation.VirtualScreen.Height);

            //Graphics graphics = Graphics.FromImage(bitmap as Image);
            //1570, 965, 1920, 1080,
            //graphics.CopyFromScreen(0, 0, 0, 0, bitmap.Size);

            //Color desiredPixelColor = ColorTranslator.FromHtml(hexcode);

            //for (int x = 0; x < SystemInformation.VirtualScreen.Width; x++)
            //{
                //for (int y = 0; y < SystemInformation.VirtualScreen.Height; y++)
                //{
                    //Color currentPixelColor = bitmap.GetPixel(x, y);

                    //if (desiredPixelColor == currentPixelColor)
                    //{
                        //MessageBox.Show("Found Pixel - Now set mouse cursor");
                        //AutoDoubleClickAtPosition(x, y);
                        //return true;
                    //}
                //}
            //}

            //MessageBox.Show("Did not find pixel");
            //return false;
        //}

        //public void AutoDoubleClickAtPosition(int posX, int posY)
        //{
            //SetCursorPos(posX, posY);

            //AutoClick();
            //System.Threading.Thread.Sleep(250);
            //AutoClick();
        //}

        //public void AutoClick()
        //{
            //mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            //mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
            //string inputHexColorCode = textBox1.Text;
            //AutoSearchPixel(inputHexColorCode);
        //}

        public void DoubleClickAtPosition(int posX, int posY)
        {
            SetCursorPos(posX, posY);

            Click();
            System.Threading.Thread.Sleep(250);
            Click();
        }

        public void Click()
        {
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string inputHexColorCode = textBox1.Text;
            SearchPixel(inputHexColorCode);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
